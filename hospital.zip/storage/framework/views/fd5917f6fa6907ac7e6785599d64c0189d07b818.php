<?php echo e($slot); ?>

<?php /**PATH E:\xampp\htdocs\hospital-1.0.1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>