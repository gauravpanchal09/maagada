<?php $__env->startPush('styles'); ?>
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/select2/dist/css/select2.min.css')); ?>">
<style rel="stylesheet">
    .select2-container .select2-selection--single {
        height: 35px !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('content-header'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('Reports')); ?>

    <small><?php echo e(__('Control panel')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('Dashboard')); ?></a></li>
    <li class="active"><?php echo e(__('Reports')); ?></li>
  </ol>
</section>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title"><?php echo e(__('Generate Report')); ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="patient"><?php echo e(__('Select Patient')); ?></label>
                            <select name="patient" class="form-control select2">
                                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($patient->id); ?>" <?php if(old('patient_id') == $patient->id): ?> selected <?php endif; ?>>
                                        #<?php echo e($patient->registration_number); ?> <?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?> ( <?php echo e($patient->madamName); ?> )
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <a href="#" class="btn btn-app pull-right">
                            <i class="fa fa-print"></i> Print
                        </a>
                    </div>
                </div>
            </div>
            <!-- /.box-body -->
            <!-- Loading (remove the following to stop the loading)-->
            <div class="overlay">
                <i class="fa fa-refresh fa-spin"></i>
            </div>
            <!-- end loading -->
        </div>
        <!-- /.box -->

        <div class="row">
            <div class="col-md-12 body-block"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Select2 -->
<script src="<?php echo e(asset('bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>

<!-- InputMask -->
<script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $('.select2').select2();

        //Money Euro
        $('span[data-mask]').inputmask();

        generateReport();
        $('select[name="patient"]').change(function (event) {
            generateReport();
        });

        function generateReport() {
            let target = $('div.body-block'),
            patient = $('select[name="patient"]').val(),
            url = "<?php echo e(route('reports.generate', ['id' => ':id'])); ?>";
            $('.box > .overlay').hide();

            if (patient > 0) {
                url = url.replace(':id', patient);
                $('.box > .overlay').show();

                $.ajax({
                    url : url,
                    type : 'GET',
                    success : function(res){
                        target.html(res);
                        $('.box > .overlay').hide();
                        //Money Euro
                        $('span[data-mask]').inputmask();
                    }
                });
            }
        }

        $('.btn-app').click(function (event) {
            event.preventDefault();
            let patient = $('select[name="patient"]').val(),
            url = "<?php echo e(route('reports.print', ['id' => ':id'])); ?>";

            if (patient > 0) {
                url = url.replace(':id', patient);
                window.open(url, '_blank');
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u106338101/domains/drmanjurathi.in/public_html/maagada/resources/views/reports/index.blade.php ENDPATH**/ ?>