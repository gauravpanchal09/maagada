<?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-xs-12">
    <div class="box box-default box-solid">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(__('Gynae Report')); ?> #<?php echo e($report->id); ?></h3>
            <div class="box-tools pull-right">
                <button data-href="<?php echo e(route('pl.edit', ['id' => $report->id])); ?>" class="btn btn-box-tool">
                    <i class="fa fa-edit"></i> Edit
                </button>
            </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <label for="description"><?php echo e(__('Description')); ?></label>
                    <div class="form-group" style="border: solid 1px #ccc; padding: 0.5rem 1rem;">
                        <?php echo $report->description ?: 'N/A'; ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.box-body -->
        <!-- Loading (remove the following to stop the loading)-->
        <div class="overlay">
            <i class="fa fa-refresh fa-spin"></i>
        </div>
        <!-- end loading -->
    </div>
    <!-- /.box -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(count($reports) === 0): ?>
<div class="col-xs-12">
    <div class="box box-warning box-solid">
        <div class="box-body"><?php echo e(__('Gynae Report not found for this patient.')); ?></div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH E:\xampp\htdocs\hospital-1.0.1\resources\views/components/pl-reports.blade.php ENDPATH**/ ?>