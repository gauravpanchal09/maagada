<div class="pull-right hidden-xs">
    
</div>
<?php /**PATH E:\xampp\htdocs\hospital-1.0.1\resources\views/layouts/includes/footer.blade.php ENDPATH**/ ?>