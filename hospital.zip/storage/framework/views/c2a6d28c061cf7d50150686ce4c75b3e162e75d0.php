<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
    <?php echo $__env->make('reports.generate', [
        'patient' => $patient,
        'ancReports' => $ancReports,
        'inReports' => $inReports,
        'plReports' => $plReports
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        $('.box > .overlay').hide();
        window.print();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u106338101/domains/drmanjurathi.in/public_html/maagada/resources/views/reports/print.blade.php ENDPATH**/ ?>