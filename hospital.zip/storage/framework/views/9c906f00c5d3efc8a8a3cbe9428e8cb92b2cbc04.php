<div class="row">
    <div class="col-xs-12">
        <div class="box box-widget widget-user">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-aqua-active">
                <h3 class="widget-user-username">#<?php echo e($patient->registration_number); ?> <?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?> Age: <?php echo e($patient->age); ?></h3>
                 <h3 class="widget-user-username text-right"><?php echo e($patient->madamName); ?></h3>
                <h5 class="widget-user-desc"><?php echo e(__('Mobile')); ?> : <?php echo e($patient->mobile ?: 'N/A'); ?></h5>
                <h5 class="widget-user-desc"><?php echo e(__('Aadhar Card')); ?> : <?php echo e($patient->aadhar_card ?: 'N/A'); ?></h5>
                <h5 class="widget-user-desc"><?php echo e($patient->address ?: 'N/A'); ?></h5>
            </div>
            <div class="widget-user-image">
                <img class="img-circle" src="<?php echo e(asset('dist/img/avatar6.png')); ?>" alt="User Avatar">
            </div>
            <div class="box-footer">
                <div class="row">
                    <!-- <div class="col-sm-4 border-right">
                        <div class="description-block">
                            <h5 class="description-header"><?php echo e(count($ancReports)); ?></h5>
                            <span class="description-text">ANC Test</span>
                        </div>
                    </div> -->
                    <!-- /.col -->
                    <div class="col-sm-12 border-right">
                        <div class="description-block">
                            <h5 class="description-header"><?php echo e(count($inReports)); ?></h5>
                            <span class="description-text">Infertility Test</span>
                        </div>
                        <!-- /.description-block -->
                    </div>
                    <!-- /.col -->
                    <!-- <div class="col-sm-4">
                        <div class="description-block">
                            <h5 class="description-header"><?php echo e(count($plReports)); ?></h5>
                            <span class="description-text">Gynae Test</span>
                        </div>
                    </div> -->
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
        </div>
    </div>
    <!-- <?php if (isset($component)) { $__componentOriginal8b52ecff86de1876488dc6b52dea8e1f8927ad10 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AncReports::class, ['reports' => $ancReports]); ?>
<?php $component->withName('anc-reports'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b52ecff86de1876488dc6b52dea8e1f8927ad10)): ?>
<?php $component = $__componentOriginal8b52ecff86de1876488dc6b52dea8e1f8927ad10; ?>
<?php unset($__componentOriginal8b52ecff86de1876488dc6b52dea8e1f8927ad10); ?>
<?php endif; ?> -->
    <?php if (isset($component)) { $__componentOriginal954d1f7f34920b8cca842ca288cfc0a29127e4cd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InReports::class, ['reports' => $inReports]); ?>
<?php $component->withName('in-reports'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal954d1f7f34920b8cca842ca288cfc0a29127e4cd)): ?>
<?php $component = $__componentOriginal954d1f7f34920b8cca842ca288cfc0a29127e4cd; ?>
<?php unset($__componentOriginal954d1f7f34920b8cca842ca288cfc0a29127e4cd); ?>
<?php endif; ?>
    <!-- <?php if (isset($component)) { $__componentOriginal2ff1aa4b28a8cb957fcc23296ada3310771a90ec = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PlReports::class, ['reports' => $plReports]); ?>
<?php $component->withName('pl-reports'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ff1aa4b28a8cb957fcc23296ada3310771a90ec)): ?>
<?php $component = $__componentOriginal2ff1aa4b28a8cb957fcc23296ada3310771a90ec; ?>
<?php unset($__componentOriginal2ff1aa4b28a8cb957fcc23296ada3310771a90ec); ?>
<?php endif; ?> -->
</div>

<script>
$(function () {
    $('.btn-box-tool').click(function (event) {
        event.preventDefault();
        const url = $(this).data('href');
        window.location.replace(url);
    });

    $('.btn-remove').click(function (event) {
        event.preventDefault();
        const url = $(this).data('href');
        $.ajax({
            url : url,
            type : 'DELETE',
            data: { "_token": "<?php echo e(csrf_token()); ?>" },
            success : function(){
                window.location.reload(true)
            }
        });
    });
});
</script>
<?php /**PATH /home/u106338101/domains/drmanjurathi.in/public_html/maagada/resources/views/reports/generate.blade.php ENDPATH**/ ?>