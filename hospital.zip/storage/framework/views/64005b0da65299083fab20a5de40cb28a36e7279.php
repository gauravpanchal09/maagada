<?php $__env->startPush('styles'); ?>
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/select2/dist/css/select2.min.css')); ?>">
<style rel="stylesheet">
    .select2-container .select2-selection--single {
        height: 35px !important;
    }

    .centered-text th, .centered-text td {
        text-align: center !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('content-header'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('Infertility')); ?>

    <small><?php echo e(__('Control panel')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('Dashboard')); ?></a></li>
    <li><a href="#"><i class="fa fa-medkit"></i><?php echo e(__('Tests')); ?></a></li>
    <li><a href="#"><i class="fa fa-circle-o"></i><?php echo e(__('Infertility')); ?></a></li>
    <li class="active"><?php echo e(__('Edit')); ?></li>
  </ol>
</section>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-body">
                <?php echo $__env->make('tests.in._form', ['test' => $test, 'patients' => $patients], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Select2 -->
<script src="<?php echo e(asset('bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $('.select2').select2()

        var files = [];
        $('input[type="file"]').change(function (event) {
            if (files.length) {
                $(this).parent().parent().children('.row').remove();
                files = [];
            }

            let target = event.target.files;
            for(let i=0; i < target.length; i++) {
                files.push({
                    "name": target[i].name,
                    "url": URL.createObjectURL(target[i])
                });
            }

            handleFileUpload($(this));
        });

        function handleFileUpload(target) {
            if (files.length && target) {
                let html = `<div class="row" style="margin-bottom: 1rem;">`;
                files.forEach(function (file) {
                    html += `
                    <div class="col-md-4">
                        <span>${file.name}</span>
                        <img class="img-thumbnail" src="${file.url}" />
                    </div>`;
                });
                html += `</div>`;
                target.parent().after(html);
            }
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u106338101/domains/drmanjurathi.in/public_html/maagada/resources/views/tests/in/edit.blade.php ENDPATH**/ ?>