<?php $__env->startPush('content-header'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('Patients')); ?>

    <small><?php echo e(__('Control panel')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('Dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('patients.index')); ?>"><i class="fa fa-users"></i><?php echo e(__('Patients')); ?></a></li>
    <li class="active"><?php echo e(__('Edit')); ?></li>
  </ol>
</section>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title"><?php echo e(__('Edit Patient')); ?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <?php echo $__env->make('patients._form', ['patient' => $patient], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- InputMask -->
<script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.date.extensions.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/input-mask/jquery.inputmask.extensions.js')); ?>"></script>

<script>
    $(function () {
      //Money Euro
      $('[data-mask]').inputmask()
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hospital-1.0.1\resources\views/patients/edit.blade.php ENDPATH**/ ?>