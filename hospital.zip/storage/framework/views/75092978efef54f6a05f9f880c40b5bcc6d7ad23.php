<?php $request = app('Illuminate\Http\Request'); ?>

<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
        <div class="pull-left image">
            <img src="<?php echo e(asset('dist/img/avatar5.png')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
            <p><?php echo e(Auth::user()->name); ?></p>
            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
    </div>

    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li class="<?php echo e($request->segment(1) === 'home' ? 'active' : ''); ?>">
            <a href="<?php echo e(url('/')); ?>">
                <i class="fa fa-dashboard"></i> <span><?php echo e(__('Dashboard')); ?></span>
            </a>
        </li>
        <!-- <li class="<?php echo e($request->segment(1) === 'hospitals' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hospitals.index')); ?>">
                <i class="fa fa-hospital-o"></i> <span><?php echo e(__('Hospitals')); ?></span>
            </a>
        </li> -->
        <li class="<?php echo e($request->segment(1) === 'patients' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('patients.index')); ?>">
                <i class="fa fa-users"></i> <span><?php echo e(__('Patients')); ?></span>
            </a>
        </li>
        <!-- <li class="<?php echo e($request->segment(1) === 'hospital-patients' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('hospital-patients.index')); ?>">
                <i class="fa fa-ambulance"></i> <span><?php echo e(__('Hospital Patients')); ?></span>
            </a>
        </li> -->
        <li class="treeview <?php echo e($request->segment(1) === 'tests' ? 'active' : ''); ?>">
            <a href="#">
                <i class="fa fa-medkit"></i> <span><?php echo e(__('Tests')); ?></span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu">
                <!-- <li class="<?php echo e($request->segment(2) === 'anc' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('anc.create')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('ANC')); ?></a>
                </li> -->
                <li class="<?php echo e($request->segment(2) === 'in' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('in.create')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('Infertility')); ?></a>
                </li>
                <!-- <li class="<?php echo e($request->segment(2) === 'pl' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('pl.create')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('Gynae')); ?></a>
                </li> -->
            </ul>
        </li>
        <!-- <li class="<?php echo e($request->segment(1) === 'monthly-pregnancies' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('monthly-pregnancies.index')); ?>">
                <i class="fa fa-calendar-plus-o"></i> <span><?php echo e(__('Monthly Pregnancies')); ?></span>
            </a>
        </li> -->
        <li class="<?php echo e($request->segment(1) === 'reports' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('reports.index')); ?>">
                <i class="fa fa-file"></i> <span><?php echo e(__('Reports')); ?></span>
            </a>
        </li>
    </ul>
</section>
<!-- /.sidebar -->
<?php /**PATH /home/u106338101/domains/drmanjurathi.in/public_html/maagada/resources/views/layouts/includes/sidebar.blade.php ENDPATH**/ ?>