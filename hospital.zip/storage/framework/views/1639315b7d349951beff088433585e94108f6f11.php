<?php $__env->startPush('styles'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('content-header'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('Hospital Patients')); ?>

    <small><?php echo e(__('Control panel')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('Dashboard')); ?></a></li>
    <li class="active"><?php echo e(__('Hospital Patients')); ?></li>
  </ol>
</section>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title"><?php echo e(__('Hospital Patients List')); ?></h3>
                <a href="<?php echo e(route('hospital-patients.create')); ?>" class="btn btn-primary pull-right">Add</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div class="table-responsive">
                    <table id="hospital_patients_table" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th><?php echo e(__('#')); ?></th>
                                <th><?php echo e(__('Registration Number')); ?></th>
                                <th><?php echo e(__('First Name')); ?></th>
                                <th><?php echo e(__('Last Name')); ?></th>
                                <th><?php echo e(__('Hospital')); ?></th>
                                <th><?php echo e(__('Created At')); ?></th>
                                <th><?php echo e(__('Action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($patient->registration_number); ?></td>
                                <td><?php echo e($patient->first_name); ?></td>
                                <td><?php echo e($patient->last_name); ?></td>
                                <td><?php echo e($patient->hospital->name); ?></td>
                                <td><?php echo e($patient->created_at); ?></td>
                                <td>
                                    <a href="<?php echo e(route('hospital-patients.edit', ['hospital_patient' => $patient])); ?>" class="btn btn-info">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="#" class="btn btn-danger">
                                        <i class="fa fa-trash"></i>
                                        <form action="<?php echo e(route('hospital-patients.destroy', ['hospital_patient' => $patient])); ?>" method="POST" class="d-none">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

<script>
  $(function () {
    $('#hospital_patients_table').DataTable();

    $('a.btn-danger').click(function (event) {
        event.preventDefault();
        if (confirm('Are you sure?')) {
            $(this).find('form').submit();
        }
    });
  })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hospital-1.0.1\resources\views/hospital_patients/index.blade.php ENDPATH**/ ?>