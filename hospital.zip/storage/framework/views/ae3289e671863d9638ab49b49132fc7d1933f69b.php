<div class="pull-right hidden-xs">
    
</div>
<?php /**PATH /home/u106338101/domains/drmanjurathi.in/public_html/maagada/resources/views/layouts/includes/footer.blade.php ENDPATH**/ ?>