<?php $__env->startPush('styles'); ?>
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('bower_components/select2/dist/css/select2.min.css')); ?>">
<style rel="stylesheet">
    .select2-container .select2-selection--single {
        height: 35px !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('content-header'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('ANC')); ?>

    <small><?php echo e(__('Control panel')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('Dashboard')); ?></a></li>
    <li><a href="#"><i class="fa fa-medkit"></i><?php echo e(__('Tests')); ?></a></li>
    <li class="active"><?php echo e(__('ANC')); ?></li>
  </ol>
</section>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-body">
                <?php echo $__env->make('tests.anc._form', [
                    'test' => null,
                    'patients' => $patients,
                    'infertilityStatuses' => $infertilityStatuses,
                    'vaccinations' => $vaccinations,
                    'bloodGroups' => $bloodGroups,
                    'history' => []
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Select2 -->
<script src="<?php echo e(asset('bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>

<script>
    $(function () {
        //Initialize Select2 Elements
        $('.select2').select2()
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\hospital-1.0.1\resources\views/tests/anc/create.blade.php ENDPATH**/ ?>