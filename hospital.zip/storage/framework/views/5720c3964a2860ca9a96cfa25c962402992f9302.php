<?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-xs-12">
    <div class="box box-primary box-solid">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(__('ANC Report')); ?> #<?php echo e($report->id); ?></h3>
            <div class="box-tools pull-right">
                <button data-href="<?php echo e(route('anc.edit', ['id' => $report->id])); ?>" class="btn btn-box-tool">
                    <i class="fa fa-edit"></i> Edit
                </button>
            </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <fieldset>
                <legend><?php echo e(__('Menstrual History')); ?></legend>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="menstrual_history_lmd"><?php echo e(__('LMP')); ?></label>
                            <span class="form-control"><?php echo e($report->menstrual_history_lmp ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="menstrual_history_edd"><?php echo e(__('EDD')); ?></label>
                            <span class="form-control"><?php echo e($report->menstrual_history_edd ?: 'N/A'); ?></span>
                        </div>
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <legend><?php echo e(__('Obstetric History')); ?></legend>
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="obstetric_history_g"><?php echo e(__('G')); ?></label>
                                    <span class="form-control"><?php echo e($report->obstetric_history_g ?: 'N/A'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="obstetric_history_p"><?php echo e(__('P')); ?></label>
                                    <span class="form-control"><?php echo e($report->obstetric_history_p ?: 'N/A'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="obstetric_history_a"><?php echo e(__('A')); ?></label>
                                    <span class="form-control"><?php echo e($report->obstetric_history_a ?: 'N/A'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="obstetric_history_l"><?php echo e(__('L')); ?></label>
                                    <span class="form-control"><?php echo e($report->obstetric_history_l ?: 'N/A'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="obstetric_history_first"><?php echo e(__('I')); ?></label>
                                    <span class="form-control"><?php echo e($report->obstetric_history_first ?: 'N/A'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="obstetric_history_second"><?php echo e(__('II')); ?></label>
                                    <span class="form-control"><?php echo e($report->obstetric_history_second ?: 'N/A'); ?></span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="obstetric_history_third"><?php echo e(__('III')); ?></label>
                                    <span class="form-control"><?php echo e($report->obstetric_history_third ?: 'N/A'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="marital_life"><?php echo e(__('Marital Life')); ?></label>
                            <span class="form-control"><?php echo e($report->marital_life ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="infertility_treatment"><?php echo e(__('Infertility Treatment')); ?></label>
                            <span class="form-control"><?php echo e($report->infertility_treatment ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="previous_surgeries"><?php echo e(__('Previous Surgeries')); ?></label>
                            <span class="form-control"><?php echo e($report->previous_surgeries ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="past_history"><?php echo e(__('Past History')); ?></label>
                            <span class="form-control"><?php echo e($report->past_history ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="family_history"><?php echo e(__('Family History')); ?></label>
                            <span class="form-control"><?php echo e($report->family_history ?: 'N/A'); ?></span>
                        </div>
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <legend><?php echo e(__('Investigation')); ?></legend>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="blood_group"><?php echo e(__('Blood Group')); ?></label>
                            <span class="form-control"><?php echo e($report->blood_group ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="hb"><?php echo e(__('HB')); ?></label>
                            <span class="form-control"><?php echo e($report->hb ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="platelets"><?php echo e(__('Platelets')); ?></label>
                            <span class="form-control"><?php echo e($report->platelets ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="hiv"><?php echo e(__('HIV')); ?></label>
                            <span class="form-control"><?php echo e($report->hiv ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="hbsag"><?php echo e(__('HBSAG')); ?></label>
                            <span class="form-control"><?php echo e($report->hbsag ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="udrl"><?php echo e(__('UDRL')); ?></label>
                            <span class="form-control"><?php echo e($report->udrl ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="urine_randm"><?php echo e(__('Urine R&M')); ?></label>
                            <span class="form-control"><?php echo e($report->urine_randm ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="tsh"><?php echo e(__('TSH')); ?></label>
                            <span class="form-control"><?php echo e($report->tsh ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="bl_suger"><?php echo e(__('BL Suger')); ?></label>
                            <span class="form-control"><?php echo e($report->bl_suger ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="ogtt"><?php echo e(__('OGTT')); ?></label>
                            <span class="form-control"><?php echo e($report->ogtt ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="hb_electro"><?php echo e(__('HB Electro')); ?></label>
                            <span class="form-control"><?php echo e($report->hb_electro ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="dual_markar"><?php echo e(__('DUAL Markar')); ?></label>
                            <span class="form-control"><?php echo e($report->dual_markar ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="quadraple_markar"><?php echo e(__('QUADRAPLE Markar')); ?></label>
                            <span class="form-control"><?php echo e($report->quadraple_markar ?: 'N/A'); ?></span>
                        </div>
                    </div>
                </div>
            </fieldset>
            <fieldset>
                <legend><?php echo e(__('General Examination')); ?></legend>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <span class="form-control"><?php echo e($report->general_examination ?: 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="vaccination"><?php echo e(__('Vaccination')); ?></label>
                            <span class="form-control"><?php echo e($report->vaccination ?: 'N/A'); ?></span>
                        </div>
                    </div>
                </div>
            </fieldset>
        </div>
        <!-- /.box-body -->
        <!-- Loading (remove the following to stop the loading)-->
        <div class="overlay">
            <i class="fa fa-refresh fa-spin"></i>
        </div>
        <!-- end loading -->
    </div>
    <!-- /.box -->
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(count($reports) === 0): ?>
<div class="col-xs-12">
    <div class="box box-warning box-solid">
        <div class="box-body"><?php echo e(__('ANC Report not found for this patient.')); ?></div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /home/u106338101/domains/drmanjurathi.in/public_html/maagada/resources/views/components/anc-reports.blade.php ENDPATH**/ ?>